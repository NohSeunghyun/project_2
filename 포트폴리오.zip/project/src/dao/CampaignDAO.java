package dao;

public class CampaignDAO {

}
