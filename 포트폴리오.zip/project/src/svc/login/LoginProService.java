package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class LoginProService {

	public String isIdChk(String id) {//id일치체크
		String isIdChk = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			isIdChk = loginDAO.isIdChk(id);
		} catch (Exception e) {
			System.out.println("loginIdChkService에러" + e);
		} finally {
			close(con);
		}
		return isIdChk;
	}

	public String isPwChk(String id, String isIdChk, String pw) {//pw일치체크
		String isPwChk = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			isPwChk = loginDAO.isPwChk(id, isIdChk, pw);
		} catch (Exception e) {
			System.out.println("loginPwChkService에러" + e);
		} finally {
			close(con);
		}
		return isPwChk;
	}

	public String name(String id) {
		String name = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			name = loginDAO.name(id);
		} catch (Exception e) {
			System.out.println("loginNameService에러" + e);
		} finally {
			close(con);
		}
		return name;
		
	}
	
}
