package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class EmailSearchIDService {
	
	public String searchID(String email) throws Exception {
		String searchID = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			searchID = loginDAO.emailSearchID(email);
		} catch (Exception e) {
			System.out.println("emailSearchIDService에러" + e);
		} finally {
			close(con);
		}
		return searchID;
	}
}
