package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class PersonalInformationService {

	public String chkPW(String id, String pw) {
		String successPW = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			successPW = loginDAO.chkPW(id, pw);
		} catch (Exception e) {
			System.out.println("infoChkPWService에러" + e);
		} finally {
			close(con);
		}
		return successPW;
	}

}
