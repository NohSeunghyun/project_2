package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class PhoneSarchIDService {

	public String searchID(String phone) throws Exception {
		String searchID = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			searchID = loginDAO.phoneSearchID(phone);
		} catch (Exception e) {
			System.out.println("phoneSearchIDService에러" + e);
		} finally {
			close(con);
		}
		return searchID;
	}
}
