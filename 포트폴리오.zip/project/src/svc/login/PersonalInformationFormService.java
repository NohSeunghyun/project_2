package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import vo.login.CompanyGroupMemberBean;
import dao.LoginDAO;
import vo.login.NormalMemberBean;

public class PersonalInformationFormService {

	public NormalMemberBean normalInfo(String id) {
		NormalMemberBean normalInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			normalInfo = loginDAO.normalInfo(id);
		} catch (Exception e) {
			System.out.println("normalInfoService에러" + e);
		} finally {
			close(con);
		}
		return normalInfo;
	}

	public CompanyGroupMemberBean comgrpInfo(String id) {
		CompanyGroupMemberBean comgrpInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			comgrpInfo = loginDAO.comgrpInfo(id);
		} catch (Exception e) {
			System.out.println("comgrpInfoService에러" + e);
		} finally {
			close(con);
		}
		return comgrpInfo;
	}

}
