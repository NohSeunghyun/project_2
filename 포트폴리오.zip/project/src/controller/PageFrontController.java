package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import action.login.EmailSearchIDProAction;
import action.login.IdOverlapCheckProAction;
import action.login.JoinMemberShip_ComgrpProAction;
import action.login.JoinMemberShip_NormalProAction;
import action.login.LoginProAction;
import action.login.PhoneSearchIDProAction;
import action.login.SearchPWProAction;
import vo.ActionForward;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("*.page")
public class PageFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PageFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		Action action = null;
		ActionForward forward = null;
		
		if (command.equals("/mainPage.page")) {//메인페이지 이동
			forward = new ActionForward("index.jsp", false);
		}
		else if (command.equals("/loginNCGMemberMainPage.page")) {//로그인 성공 후 메인페이지 이동
			forward = new ActionForward("/member/index.jsp", false);
		}
		else if (command.equals("/loginFrom.page")) {//로그인 화면
			forward = new ActionForward("/login/loginForm.jsp", false);
		}
		else if (command.equals("/memberLogin.page")) {//일반,기업/단체 회원 로그인성공 index 화면
			forward = new ActionForward("/member/index.jsp", false);
		}
		else if (command.equals("/adminLogin.page")) {//관리자 로그인성공 index 화면
			forward = new ActionForward("/admin/index.jsp", false);
		}
		else if (command.equals("/checkCategoryForm.page")) {//회원가입 전 일반,기업/단체 구분 체크 화면
			forward = new ActionForward("/login/checkCategory.jsp", false);
		}
		else if (command.equals("/joinMemberShip_normal_Form.page")) {//일반회원 회원가입 화면
			forward = new ActionForward("/login/joinMemberShip_normal_Form.jsp", false);
		}
		else if (command.equals("/joinMemberShip_comgrp_Form.page")) {//기업/단체 회원가입 화면
			forward = new ActionForward("/login/joinMemberShip_comgrp_Form.jsp", false);
		}
		else if (command.equals("/idOverlapCheckForm.page")) {//아이디 중복 체크  화면 
			forward = new ActionForward("/login/idOverlapChkForm.jsp", false);
		}
		else if (command.equals("/idOverlapCheckSuccessForm.page")) {//아이디 중복 성공 후  화면 
			forward = new ActionForward("/login/idOverlapChkSuccess.jsp", false);
		}
		else if (command.equals("/joinMemberShipSuccess.page")) {//회원가입 성공 후 로그인 화면
			forward = new ActionForward("/login/joinMemberShip_Success.jsp", false);
		}
		else if (command.equals("/searchIDForm.page")) {//아이디 찾기 화면
			forward = new ActionForward("/login/searchIDForm.jsp", false);
		}
		else if (command.equals("/phone_searchID_Form.page")) {//핸드폰번호로 아이디 찾기 화면
			forward = new ActionForward("/login/phone_searchIDForm.jsp", false);
		}
		else if (command.equals("/email_searchID_Form.page")) {//이메일주소로 아이디 찾기 화면
			forward = new ActionForward("/login/email_searchIDForm.jsp", false);
		}
		else if (command.equals("/searchPWForm.page")) {//비밀번호 찾기 화면
			forward = new ActionForward("/login/searchPWForm.jsp", false);
		}
		else if (command.equals("/personalInformation.page")) {//개인정보조회 전 비밀번호 확인 화면
			forward = new ActionForward("/member/personalInformationChkPW.jsp", false);
		}
		else if (command.equals("/normalMemberPersonalInformationForm.page")) {//일반회원 개인정보조회 화면
			forward = new ActionForward("/member/normalMemberPersonalInformationForm.jsp", false);
		}
		else if (command.equals("/comgrpMemberPersonalInformationForm.page")) {//기업/단체 회원 개인정보조회 화면
			forward = new ActionForward("/member/comgrpMemberPersonalInformationForm.jsp", false);
		}
		else if (command.equals("/changeNameForm.page")) {//개인정보 이름 변경 화면
			forward = new ActionForward("/member/changeNameForm.jsp", false);
		}
		else if (command.equals("/changePhoneForm.page")) {//개인정보 휴대폰번호 변경 화면
			forward = new ActionForward("/member/changePhoneForm.jsp", false);
		}
		else if (command.equals("/changeEmailForm.page")) {//개인정보 이메일 변경 화면
			forward = new ActionForward("/member/changeEmailForm.jsp", false);
		}
		else if (command.equals("/changePWForm.page")) {//개인정보 비밀번호 변경 화면
			forward = new ActionForward("/member/changePWForm.jsp", false);
		}
		else if (command.equals("/deleteSuccess.page")) {//회원탈퇴 후 알람화면
			forward = new ActionForward("/alert/deleteAlert.jsp", false);
		}
		else if (command.equals("/changePwSuccess.page")) {//비밀번호 변경 후 알람화면
			forward = new ActionForward("/alert/changePwAlert.jsp", false);
		}
		else if (command.equals("/MemberUpdateSuccess.page")) {//개인정보 수정 후 알람화면
			forward = new ActionForward("/alert/memberUpdateAlert.jsp", false);
		}
		
		/******************************포워딩******************************/
		
		if(forward != null) {
			if(forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
			request.getRequestDispatcher(forward.getPath()).forward(request, response);
			}
		}
	}
}


